import ConfirmationModal from "./ConfirmationModal";
import { binSVG } from "../../svg/svg";

interface MemberProps {
    member: any;
  }



const Example:React.FC<MemberProps> = ({member}) => {
  const handleCancel = () => {
    console.log("Cancel clicked");
  };

  const handleRemove = () => {
    console.log("Remove clicked");
  };

  const description = <>Are you sure you want to remove{" "}<span style={{ color: "#14171A" }}>{member.name}</span> from your team?</>

  return (
    <ConfirmationModal
      title="Remove Member?"
      description={description}
      svgContent={binSVG}
      buttons={[
        {
          text: "Cancel",
          onClick: handleCancel,
          styles: { background: "#AAB8C2", color: "#14171A", width:'408px', height:'42px'},
        },
        {
          text: "Remove",
          onClick: handleRemove,
          styles: { background: "#EB5244", color: "#FFFFFF", width:'408px', height:'42px' },
        },
      ]}
    />
  );
};

export default Example;
