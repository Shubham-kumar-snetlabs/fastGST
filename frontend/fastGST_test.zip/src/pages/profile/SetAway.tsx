import React from 'react'

const SetAway = () => {
  return (
    <div>SetAway</div>
  )
}

export default SetAway