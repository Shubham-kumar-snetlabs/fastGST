import styled from 'styled-components';
import TitleName from '../../components/atoms/TitleName';
import { crossSVG, TimerIconSVG, verifyOTPSVG } from '../../svg/svg';
import OTPDescription from '../../components/molecules/OTPDescription';
import EnterOTPBox from '../../components/molecules/EnterOTPBox';
import MultiFunctionButtonComponent from '../../components/atoms/MultiFunctionButtonComponent';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';


const Container = styled.div<{ background: string }>`
  height: 100%;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background: ${({ background }) => background};
  z-index: 999;
`;

const RightContainer = styled.div`
  flex: 1;
  background: transparent;
  height: auto;
  width: auto;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const InnerRightContainer = styled.div`
  height: auto;
  width: 504px;
  background: white;
  display: flex;
  flex-direction : column;
  justify-content: center;
  align-items: center;
  color: #14171A;
  border-radius : 12px;
  padding : 20px;
  box-sizing : border-box;
`;
const CrossDiv = styled.div`
    width : 100%;
    height : auto;
    // background : red;
    display : flex;
    justify-content : flex-end;
`;

const VerifyKYCContainer = styled.div`
  height: 358px;
  width: 336px;
  display: flex;
  gap: 16px;
  flex-direction: column;
  align-items: center;
`;

const OTPandButtonDiv = styled.div`
  height: 110px;
  width : 228px;
  display : flex;
  flex-direction : column;
  gap : 20px;
`;

const Timer = styled.div`
  color : #4D4D4D;
  display : flex;
  align-items : center;
  gap : 4px;

  font-family: Noto Sans;
  font-size: 16px;
  font-weight: 400;
  line-height: 16px;
  text-align: center;
  text-underline-position: from-font;
  text-decoration-skip-ink: none;
`;

const OTPModal = () => {
    const navigate = useNavigate();

  const handleVerifyKYC = () => {
    navigate('/');
  }

   const [timeLeft, setTimeLeft] = useState(600);

     useEffect(() => {
       if (timeLeft === 0) return; // Stop when time reaches 0
   
       const timer = setInterval(() => {
         setTimeLeft((prevTime) => prevTime - 1);
       }, 1000);
   
       return () => clearInterval(timer); // Cleanup interval on unmount
     }, [timeLeft]);
   
     // Convert seconds to MM:SS format
     const formatTime = (seconds: number) => {
       const minutes = Math.floor(seconds / 60);
       const secs = seconds % 60;
       return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
     };
  
  return (
    <Container background='#000000CC'>
        <RightContainer>
          <InnerRightContainer>
          <CrossDiv onClick={()=>navigate('/profile/view-profile')}>{crossSVG}</CrossDiv>
            <VerifyKYCContainer>
              <TitleName svgContent={verifyOTPSVG} title="OTP Verification" />
              <OTPDescription description='One Time Password has been sent to your Adhaar linked mobile number.'/>
              <OTPandButtonDiv>
              <EnterOTPBox
                width='228px'
                height='48px'
                gap='8px'
                padding='8px'
                boxHeight='48px'
                boxWidth='48px'
              />
              <MultiFunctionButtonComponent
                onClick={handleVerifyKYC}
                text="Verify"
                width="228px"
              />
              </OTPandButtonDiv>

            </VerifyKYCContainer>
            <Timer>{TimerIconSVG} {formatTime(timeLeft)}</Timer>
          </InnerRightContainer>
        </RightContainer>
    </Container>
  )
}

export default OTPModal