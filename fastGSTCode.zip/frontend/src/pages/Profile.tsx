import React from 'react'
import Layout from '../layout/Layout';
import styled from 'styled-components';
import TopNavigatingBar from '../components/molecules/TopNavigatingBar';
import DashBoardTitle from '../components/atoms/deprecated/DashBoardHead';
import { ProfileBigIconSVG } from '../svg/svg';


const InnerRightContainer = styled.div`
  height: 100%;
  width: 100%;
  min-width: 984px;
  min-height: 824px;
  display: flex;
  flex-direction: column;
  
`;

const NavigatingTopBar = styled.div`
  width: 100%;
  min-width: 984px;
  height: 48px;
  background: #f5f8fa;
  border: 2px solid #e1e8ed;
  border-radius: 16px 16px 0 0;
  box-sizing: border-box;
`;


const ContentContainer = styled.div`
  height: 100%;
  width: 100%;
  min-width: 984px;
  min-height: 776px;
  border-right: 2px solid #e1e8ed;
  border-bottom: 2px solid #e1e8ed;
  border-left: 2px solid #e1e8ed;
  display: flex;
  gap: 10px;
  padding: 32px 48px 0 48px;
  box-sizing: border-box;
  background: #f5f8fa;
`;

const ContentMainContainer = styled.div`
  height: 100%;
  width: 100%;
  min-height: 744px;
  min-width: 888px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 32px;
  border-bottom-right-radius: 16px;
  border-bottom-left-radius: 16px;
`;

const TitleContainer = styled.div`
  width: 100%;
  min-width: 888px;
  height: 60px;
  border-bottom: 1px;
  padding-top: 4px;
  padding-bottom: 4px;
  box-sizing: border-box;
  display: flex;
  gap: 10px;
  align-items: center;
`;

const BodyContainer = styled.div`
  height: 100%;
  width: 100%;
  min-height: 672px;
  min-width: 888px;
  display: flex;
  gap: 10px;
  justify-content: center;
`;



interface DashBoardLeftProps {
    activeItem: number;
    setActiveItem: (id: number) => void;
  }

const Profile : React.FC<DashBoardLeftProps> = ({activeItem, setActiveItem}) => {
return(
    <Layout activeItem={activeItem} setActiveItem={setActiveItem}>
        <InnerRightContainer>
            <NavigatingTopBar>
                <TopNavigatingBar
                mainText = 'Profile'
                showBackButton = {false}
                showExtendedRoutes = {false} />
            </NavigatingTopBar>
            <ContentContainer>
                <ContentMainContainer>
                    <TitleContainer>
                        <DashBoardTitle
                        svg = {ProfileBigIconSVG}
                        headTitle='Profile' 
                        textGap='0px'
                        />
                    </TitleContainer>
                    <BodyContainer>
                        
                    </BodyContainer>
                </ContentMainContainer>
            </ContentContainer>
        </InnerRightContainer>
    </Layout>
)
}

export default Profile;